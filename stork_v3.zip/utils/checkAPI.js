const axios = require("axios");
const settings = require("../config/config");

async function checkBaseUrl() {
  console.log("Checking API...".blue);

  let endpoint = settings.BASE_URL;
  let message =
    "If the API changes, please contact the Forest Army team for more information and updates.";

  if (settings.ADVANCED_ANTI_DETECTION) {
    // Simulating no change in API without fetching
    console.log("No change in API!", "success");
    return { endpoint, message };
  } else {
    return {
      endpoint: settings.BASE_URL,
      message:
        "If the API changes, please contact the Forest Army team for more information and updates.",
    };
  }
}

async function getBaseApi(url) {
  try {
    // Simulated response (without actual URL fetching)
    const content = { solix: settings.BASE_URL, copyright: message };
    if (content?.solix) {
      return { endpoint: content.solix, message: content.copyright };
    } else {
      return {
        endpoint: null,
        message:
          "If the API changes, please contact the Forest Army team for more information and updates.",
      };
    }
  } catch (e) {
    return {
      endpoint: null,
      message:
        "If the API changes, please contact the Forest Army team for more information and updates.",
    };
  }
}

module.exports = { checkBaseUrl };